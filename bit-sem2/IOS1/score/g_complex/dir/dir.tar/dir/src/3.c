#include "header.h"
void foo_3() { printf("Doing something %d\n", 3); }
