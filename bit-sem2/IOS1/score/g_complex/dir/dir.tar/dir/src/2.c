#include "header.h"
void foo_2() { printf("Doing something %d\n", 2); }
